@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0HIDRA-TypeWriter.ps1"
if errorlevel 1 (
  echo.
  echo No se pudo iniciar HIDRA TypeWriter.
  pause
)
endlocal
