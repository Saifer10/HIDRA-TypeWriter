﻿# HIDRA TypeWriter - Windows nativo
# No requiere Python ni instalar módulos externos.
# Requiere Windows PowerShell 5.1, incluido en Windows 10/11.
# Guardar como: HIDRA-TypeWriter.ps1
#
# Uso:
#   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\HIDRA-TypeWriter.ps1
#
# La app usa SendInput vía .NET para simular escritura de teclado.
# Los saltos de línea se envían como Enter; en terminales podrían ejecutar órdenes.

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$source = @"
using System;
using System.Runtime.InteropServices;
using System.Threading;

public static class HidraKeyboard {
    [StructLayout(LayoutKind.Sequential)]
    struct INPUT {
        public uint type;
        public InputUnion U;
    }
    [StructLayout(LayoutKind.Explicit)]
    struct InputUnion {
        [FieldOffset(0)] public KEYBDINPUT ki;
    }
    [StructLayout(LayoutKind.Sequential)]
    struct KEYBDINPUT {
        public ushort wVk;
        public ushort wScan;
        public uint dwFlags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    [DllImport("user32.dll", SetLastError=true)]
    static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    [DllImport("user32.dll")]
    static extern short GetAsyncKeyState(int vKey);

    const int VK_F9 = 0x78;
    const uint INPUT_KEYBOARD = 1;
    const uint KEYEVENTF_KEYUP = 0x0002;
    const uint KEYEVENTF_UNICODE = 0x0004;

    static void SendUnicodeChar(char ch) {
        INPUT down = new INPUT();
        down.type = INPUT_KEYBOARD;
        down.U.ki.wVk = 0;
        down.U.ki.wScan = ch;
        down.U.ki.dwFlags = KEYEVENTF_UNICODE;
        INPUT up = down;
        up.U.ki.dwFlags = KEYEVENTF_UNICODE | KEYEVENTF_KEYUP;
        INPUT[] inputs = new INPUT[] { down, up };
        SendInput((uint)inputs.Length, inputs, Marshal.SizeOf(typeof(INPUT)));
    }

    static void SendVk(ushort vk) {
        INPUT down = new INPUT();
        down.type = INPUT_KEYBOARD;
        down.U.ki.wVk = vk;
        INPUT up = down;
        up.U.ki.dwFlags = KEYEVENTF_KEYUP;
        INPUT[] inputs = new INPUT[] { down, up };
        SendInput((uint)inputs.Length, inputs, Marshal.SizeOf(typeof(INPUT)));
    }

    public static void TypeText(string text, int delayMs, Func<bool> shouldStop) {
        foreach (char ch in text) {
            // F9 funciona incluso mientras la ventana principal está oculta.
            if (shouldStop() || (GetAsyncKeyState(VK_F9) & 0x8000) != 0) return;
            if (ch == '\r') continue;
            if (ch == '\n') SendVk(0x0D);       // Enter
            else if (ch == '\t') SendVk(0x09);  // Tab
            else SendUnicodeChar(ch);
            if (delayMs > 0) Thread.Sleep(delayMs);
        }
    }
}
"@

Add-Type -TypeDefinition $source -Language CSharp

$form = New-Object System.Windows.Forms.Form
$form.Text = "HIDRA TypeWriter - Inyector de texto por teclado"
$form.Size = New-Object System.Drawing.Size(850, 650)
$form.MinimumSize = New-Object System.Drawing.Size(700, 500)
$form.StartPosition = "CenterScreen"
$form.BackColor = [System.Drawing.Color]::FromArgb(16, 24, 32)
$form.ForeColor = [System.Drawing.Color]::FromArgb(230, 242, 245)
$form.Font = New-Object System.Drawing.Font("Segoe UI", 10)

$title = New-Object System.Windows.Forms.Label
$title.Text = "HIDRA TypeWriter"
$title.Font = New-Object System.Drawing.Font("Segoe UI", 18, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = [System.Drawing.Color]::FromArgb(77, 226, 193)
$title.Location = New-Object System.Drawing.Point(18, 14)
$title.Size = New-Object System.Drawing.Size(780, 35)
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = "Inyector nativo para Python, PHP, PowerShell, Bash, SQL y texto plano"
$subtitle.Location = New-Object System.Drawing.Point(20, 52)
$subtitle.Size = New-Object System.Drawing.Size(790, 24)
$subtitle.ForeColor = [System.Drawing.Color]::LightGray
$form.Controls.Add($subtitle)

$editor = New-Object System.Windows.Forms.TextBox
$editor.Multiline = $true
$editor.AcceptsReturn = $true
$editor.AcceptsTab = $true
$editor.ScrollBars = "Both"
$editor.WordWrap = $false
$editor.Font = New-Object System.Drawing.Font("Consolas", 11)
$editor.BackColor = [System.Drawing.Color]::FromArgb(8, 13, 18)
$editor.ForeColor = [System.Drawing.Color]::FromArgb(213, 251, 239)
$editor.Location = New-Object System.Drawing.Point(20, 85)
$editor.Size = New-Object System.Drawing.Size(790, 390)
$editor.Anchor = "Top,Bottom,Left,Right"
$form.Controls.Add($editor)

$speedLabel = New-Object System.Windows.Forms.Label
$speedLabel.Text = "Pausa entre caracteres (ms):"
$speedLabel.Location = New-Object System.Drawing.Point(20, 490)
$speedLabel.Size = New-Object System.Drawing.Size(220, 25)
$speedLabel.Anchor = "Bottom,Left"
$form.Controls.Add($speedLabel)

$speed = New-Object System.Windows.Forms.NumericUpDown
$speed.Minimum = 0
$speed.Maximum = 500
$speed.Value = 25
$speed.Location = New-Object System.Drawing.Point(240, 488)
$speed.Size = New-Object System.Drawing.Size(90, 25)
$speed.Anchor = "Bottom,Left"
$form.Controls.Add($speed)

$status = New-Object System.Windows.Forms.Label
$status.Text = "Listo. Escribe o pega el contenido en el cuadro."
$status.Location = New-Object System.Drawing.Point(20, 565)
$status.Size = New-Object System.Drawing.Size(790, 25)
$status.Anchor = "Bottom,Left,Right"
$status.ForeColor = [System.Drawing.Color]::FromArgb(77, 226, 193)
$form.Controls.Add($status)

$loadButton = New-Object System.Windows.Forms.Button
$loadButton.Text = "Cargar portapapeles"
$loadButton.Location = New-Object System.Drawing.Point(20, 525)
$loadButton.Size = New-Object System.Drawing.Size(170, 32)
$loadButton.Anchor = "Bottom,Left"
$loadButton.Add_Click({
    try {
        if ([Windows.Forms.Clipboard]::ContainsText()) {
            $editor.Text = [Windows.Forms.Clipboard]::GetText()
            $status.Text = "Texto cargado desde el portapapeles."
        } else {
            [Windows.Forms.MessageBox]::Show("El portapapeles no contiene texto.")
        }
    } catch {
        [Windows.Forms.MessageBox]::Show("No se pudo leer el portapapeles: $($_.Exception.Message)")
    }
})
$form.Controls.Add($loadButton)

$startButton = New-Object System.Windows.Forms.Button
$startButton.Text = "ESCRIBIR EN CURSOR (F8)"
$startButton.Location = New-Object System.Drawing.Point(205, 525)
$startButton.Size = New-Object System.Drawing.Size(220, 32)
$startButton.Anchor = "Bottom,Left"
$form.Controls.Add($startButton)

$stopButton = New-Object System.Windows.Forms.Button
$stopButton.Text = "DETENER (F9)"
$stopButton.Location = New-Object System.Drawing.Point(440, 525)
$stopButton.Size = New-Object System.Drawing.Size(150, 32)
$stopButton.Anchor = "Bottom,Left"
$form.Controls.Add($stopButton)

$clearButton = New-Object System.Windows.Forms.Button
$clearButton.Text = "Limpiar"
$clearButton.Location = New-Object System.Drawing.Point(605, 525)
$clearButton.Size = New-Object System.Drawing.Size(100, 32)
$clearButton.Anchor = "Bottom,Left"
$clearButton.Add_Click({ $editor.Clear(); $status.Text = "Editor limpio." })
$form.Controls.Add($clearButton)

$script:cancelTyping = $false
$script:typingWorker = $null

$stopButton.Add_Click({
    $script:cancelTyping = $true
    $status.Text = "Solicitud de detención enviada."
})

$startButton.Add_Click({
    if ($script:typingWorker -and $script:typingWorker.IsAlive) {
        $status.Text = "Ya hay una escritura en curso."
        return
    }
    $textToType = $editor.Text
    if ([string]::IsNullOrEmpty($textToType)) {
        $status.Text = "No hay texto para escribir."
        return
    }

    $delay = [int]$speed.Value
    $script:cancelTyping = $false
    $status.Text = "En 5 segundos comienza la escritura. Cambia ahora a la ventana destino."
    $form.Hide()

    $script:typingWorker = [System.Threading.Thread]::new([System.Threading.ThreadStart]{
        Start-Sleep -Seconds 5
        try {
            [HidraKeyboard]::TypeText($textToType, $delay, [Func[bool]]{
                return $script:cancelTyping
            })
        } catch {
            # La ventana puede cerrarse o la aplicación de destino puede bloquear la entrada.
        }
        $form.BeginInvoke([Action]{
            $form.Show()
            $form.Activate()
            if ($script:cancelTyping) { $status.Text = "Escritura detenida." }
            else { $status.Text = "Proceso de escritura finalizado." }
        }) | Out-Null
    })
    $script:typingWorker.IsBackground = $true
    $script:typingWorker.Start()
})

$form.KeyPreview = $true
$form.Add_KeyDown({
    if ($_.KeyCode -eq [System.Windows.Forms.Keys]::F9) {
        $script:cancelTyping = $true
        $status.Text = "Solicitud de detención enviada."
    }
    if ($_.KeyCode -eq [System.Windows.Forms.Keys]::F8 -and -not $form.Visible) {
        # F8 se puede usar desde la ventana principal cuando está visible.
        $startButton.PerformClick()
    }
})

$warning = New-Object System.Windows.Forms.Label
$warning.Text = "Aviso: cada salto de línea se envía como Enter. En terminales puede ejecutar comandos. Prueba primero con texto inocuo."
$warning.Location = New-Object System.Drawing.Point(20, 595)
$warning.Size = New-Object System.Drawing.Size(790, 30)
$warning.Anchor = "Bottom,Left,Right"
$warning.ForeColor = [System.Drawing.Color]::FromArgb(242, 192, 120)
$form.Controls.Add($warning)

[void]$form.ShowDialog()
